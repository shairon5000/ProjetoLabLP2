/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.planosaude;

import java.util.ArrayList;

/**
 *
 * @author matheuscruz
 */
public class Procedimento {
    
    
    private ArrayList<ItemDoProcedimento>itemProcedimento = new ArrayList();
    private ArrayList<PlanoDeSaúde>planos = new ArrayList();
    
    private String nome;

    public Procedimento(String nome) {
        this.nome = nome;
    }

    public ArrayList<ItemDoProcedimento> getItemDeProcedimentos() {
        return itemProcedimento;
    }

    public void setItemDeProcedimentos(ArrayList<ItemDoProcedimento> itemProcedimento) {
        this.itemProcedimento = itemProcedimento;
    }
    
    public void addPlano(PlanoDeSaúde planos) {
        this.planos.add(planos);
    }

    public ArrayList<PlanoDeSaúde> getPlanos() {
        return planos;
    }

    public void setPlanos(ArrayList<PlanoDeSaúde> planos) {
        this.planos = planos;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }    
}

