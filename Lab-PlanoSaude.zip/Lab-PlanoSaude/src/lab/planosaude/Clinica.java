/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.planosaude;

import java.util.ArrayList;

/**
 *
 * @author matheuscruz
 */
public class Clinica extends Local{
    private String medicoResponsavel;
    private ArrayList<Ambulatorial>ambulatoria = new ArrayList();

    public Clinica(String medicoResponsavel, long cep) {
        super(cep);
        this.medicoResponsavel = medicoResponsavel;
    }

    public String getMedicoResponsavel() {
        return medicoResponsavel;
    }

    public void setMedicoResponsavel(String medicoResponsavel) {
        this.medicoResponsavel = medicoResponsavel;
    }

    public ArrayList<Ambulatorial> getAmbulatoria() {
        return ambulatoria;
    }

    public void setAmbulatoria(ArrayList<Ambulatorial> ambulatoria) {
        this.ambulatoria = ambulatoria;
    }    
}

