/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.planosaude;

import java.util.ArrayList;

/**
 *
 * @author 31437435
 */
public class Estado {
        private ArrayList<Autorizacao> autorizacoes = new ArrayList();

    public Estado() {
    }

    public ArrayList<Autorizacao> getAutorizacoes() {
        return autorizacoes;
    }

    public void setAutorizacoes(ArrayList<Autorizacao> autorizacoes) {
        this.autorizacoes = autorizacoes;
    }
    
    public void addAutorizacao(Autorizacao autorizacoes){
        this.autorizacoes.add(autorizacoes);
    }
    
    public enum EstadoEnum{
        PENDENTE("Pendente"), AUTORIZADO("Autorizado"), NEGADO("Negado");
        public String estado = "Pendente";
        
        EstadoEnum(String estado){
            this.estado = estado;
        }        
    }
}
