/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.planosaude;

import java.util.ArrayList;

/**
 *
 * @author 31437435 - Matheus Rocha Cruz
 */
public class Segurado {
    private ArrayList<PlanoDeSaúde>planos = new ArrayList();
    private ArrayList<Autorizacao>autorizacoes = new ArrayList();
    private String nome;
    private long cpf;

    public Segurado(String nome, long cpf) {
        this.nome = nome;
        this.cpf = cpf;
    }

    public ArrayList<Autorizacao> getAutorizacoes() {
        return autorizacoes;
    }

    public void setAutorizacoes(ArrayList<Autorizacao> autorizacoes) {
        this.autorizacoes = autorizacoes;
    }
    
    public void addPlano(PlanoDeSaúde planos) {
        this.planos.add(planos);
    }

    public ArrayList<PlanoDeSaúde> getPlanos() {
        return planos;
    }

    public void setPlanos(ArrayList<PlanoDeSaúde> planos) {
        this.planos = planos;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public long getCpf() {
        return cpf;
    }

    public void setCpf(long cpf) {
        this.cpf = cpf;
    }
}
