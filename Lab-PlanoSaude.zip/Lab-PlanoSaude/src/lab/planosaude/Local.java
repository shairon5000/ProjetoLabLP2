/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.planosaude;

import java.util.ArrayList;


/**
 *
 * @author 31437435
 */
public class Local {
    private long cep;
    private ArrayList<Autorizacao>autorizacoes = new ArrayList();

    public Local(long cep) {
        this.cep = cep;
    }

    public long getCep() {
        return cep;
    }

    public void setCep(long cep) {
        this.cep = cep;
    }

    public ArrayList<Autorizacao> getAutorizacoes() {
        return autorizacoes;
    }

    public void setAutorizacoes(ArrayList<Autorizacao> autorizacoes) {
        this.autorizacoes = autorizacoes;
    }   
}
