/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.planosaude;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author 31437435
 */
public class Autorizacao {
    private String data;
    private ArrayList<ItemDoProcedimento>itemDoProcedimentos = new ArrayList();

    public Autorizacao() {
    }    

    public ArrayList<ItemDoProcedimento> getItemDoProcedimentos() {
        return itemDoProcedimentos;
    }

    public void setItemDoProcedimentos(ArrayList<ItemDoProcedimento> itemDoProcedimentos) {
        this.itemDoProcedimentos = itemDoProcedimentos;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
