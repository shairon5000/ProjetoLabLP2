/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.planosaude;

import java.util.ArrayList;

/**
 *
 * @author matheuscruz
 */
public class Hospital extends Local{
    private ArrayList<Cirurgico>cirurgicos = new ArrayList();
    private int qntDeMedicos;

    public Hospital(int qntDeMedicos, long cep) {
        super(cep);
        this.qntDeMedicos = qntDeMedicos;
    }

    public ArrayList<Cirurgico> getCirurgicos() {
        return cirurgicos;
    }

    public void setCirurgicos(ArrayList<Cirurgico> cirurgicos) {
        this.cirurgicos = cirurgicos;
    }

    public int getQntDeMedicos() {
        return qntDeMedicos;
    }

    public void setQntDeMedicos(int qntDeMedicos) {
        this.qntDeMedicos = qntDeMedicos;
    }    
}

