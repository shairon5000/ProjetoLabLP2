/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.planosaude;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author 31437435 - Matheus Rocha Cruz
 */
public class LabPlanoSaude {

    /**
     * @param args the command line arguments
     */
    

    static ArrayList<Segurado> segurados = new ArrayList();
    static ArrayList<PlanoDeSaúde> planos = new ArrayList();
    static ArrayList<Operadora> operadoras = new ArrayList();
    static ArrayList<Procedimento> procedimentos = new ArrayList();
    static Autorizacao autoriza = new Autorizacao();
    static Scanner Int = new Scanner(System.in);
    static Scanner string = new Scanner(System.in);
    static Scanner Long = new Scanner(System.in);
    static int op, opPlano, opOperadora, opOperadora2, opAut;
    
    public static void main(String[] args) {
        ArrayList<Clinica> clinicas = new ArrayList();
        Date data = new Date(System.currentTimeMillis());
        SimpleDateFormat formatarDate = new SimpleDateFormat("DD/MM/YYYY");
        long numAut, cpf, cep;
        String nomePlano, nomeSegurado, nomeProcedimento, nomeClinica, nomeHospital;
        boolean val = true;
        int opSegurado, opProcedimento, outroPlano, qtdMed, qtdTec;

        //
        //CADASTRO DE:
        //OPERADORAS
        //PLANOS
        //SEGURADOS
        autoriza.setData(formatarDate.format(data));
        Operadora operadora1 = new Operadora("Operadora XPTO");
        operadoras.add(operadora1);
        Operadora operadora2 = new Operadora("Operadora 2 ");
        operadoras.add(operadora2);
        Segurado segurado1 = new Segurado("Matheus Rocha", 1);
        segurados.add(segurado1);
        Segurado segurado2 = new Segurado("Juliana Ramos", 2);
        segurados.add(segurado2);
        Segurado segurado3 = new Segurado("Gustavo Almeida", 3);
        segurados.add(segurado3);
        PlanoDeSaúde plano1 = new PlanoDeSaúde("Cruz Azul", 1);
        planos.add(plano1);
        PlanoDeSaúde plano2 = new PlanoDeSaúde("Unimed Paulistana", 2);
        planos.add(plano2);
        plano1.addSegurado(segurado1);
        plano2.addSegurado(segurado2);
        plano2.addSegurado(segurado3);
        operadora1.addPlano(plano1);
        operadora2.addPlano(plano2);
        segurado1.addPlano(plano1);
        segurado2.addPlano(plano2);
        segurado3.addPlano(plano2);
        //***********************************************
        Menu();

        while (op != 0) {
            switch (op) {
                case 1:
                    System.out.println("•CADASTRAR PLANO•");
                    MenuOperadora();
                    System.out.print("Digite nome do plano: ");
                    nomePlano = string.nextLine();
                    for (int i = 0; i < operadoras.size(); i++) {
                        for (int j = 0; j < operadoras.get(i).getPlanos().size(); j++) {
                            while (operadoras.get(i).getPlanos().get(j).getNome().equals(nomePlano)) {
                                System.out.println("Plano já cadastrado");
                                System.out.print("Digite outro plano: ");
                                i = 0;
                                j = 0;
                                nomePlano = string.nextLine();
                            }
                        }
                    }
                    System.out.print("Digite o número de autorização: ");
                    numAut = Long.nextLong();
                    PlanoDeSaúde p = new PlanoDeSaúde(nomePlano, numAut);
                    planos.add(p);
                    operadoras.get(opOperadora - 1).addPlano(p);
                    System.out.println("Plano cadastrado.");
                    break;

                case 2:
                    System.out.println("•Cadastrar um Segurado em um plano•");
                    System.out.print("Digite nome do segurado: ");
                    nomeSegurado = string.nextLine();
                    for (int i = 0; i < segurados.size(); i++) {
                        while (segurados.get(i).getNome().equals(nomeSegurado)) {
                            System.out.println("Segurado já cadastrado.");
                            System.out.print("Digite o nome do segurado: ");
                            nomeSegurado = string.nextLine();
                        }
                    }
                    System.out.print("Digite o CPF: ");
                    cpf = Long.nextLong();
                    for (int i = 0; i < segurados.size(); i++) {
                        while (segurados.get(i).getCpf() == cpf) {
                            System.out.println("CPF já cadastrado.");
                            System.out.print("Digite o CPF: ");
                            cpf = Long.nextLong();
                        }
                    }
                    Segurado segurado = new Segurado(nomeSegurado, cpf);
                    segurados.add(segurado);
                    MenuOperadora();
                    PlanosOperadora();
                    segurado.addPlano(operadoras.get(opOperadora - 1).getPlanos().get(opPlano - 1));
                    planos.get(opPlano - 1).addSegurado(segurado);
                    System.out.println("Deseja cadastrar outro plano ?");
                    System.out.print("Digite 1 para sim ou Digite 2 para não");
                    outroPlano = Int.nextInt();
                    while (outroPlano < 1 || outroPlano > 2) {
                        System.out.println("Inválido");
                        System.out.println("Deseja cadastrar outro plano ?");
                        System.out.print("Digite 1 para sim ou Digite 2 para não");
                        outroPlano = Int.nextInt();
                    }
                    while (outroPlano == 1) {
                        MenuOperadora();
                        opOperadora2 = opOperadora;
                        PlanosOperadora();
                        for (int j = 0; j < segurados.get(segurados.size() - 1).getPlanos().size(); j++) {
                            if (segurados.get(segurados.size() - 1).getPlanos().get(j).getNome() == operadoras.get(opOperadora - 1).getPlanos().get(opPlano - 1).getNome()) {
                                System.out.println("Plano já está cadastrado ao segurado.");
                                val = false;
                            }
                        }

                        if (val == true) {
                            segurado.addPlano(operadoras.get(opOperadora - 1).getPlanos().get(opPlano - 1));
                        }
                        System.out.println("Deseja cadastrar outro plano ?");
                        System.out.print("Digite 1 para sim ou Digite 2 para não");
                        outroPlano = Int.nextInt();
                        while (outroPlano < 1 || outroPlano > 2) {
                            System.out.println("Opção inválida");
                            System.out.print("Deseja cadastrar outro plano? 1-sim | 2-não: ");
                            outroPlano = Int.nextInt();
                        }
                    }
                    System.out.println("Segurado " + segurado.getNome() + " cadastrado ao(s) plano(s): ");
                    for (int i = 0; i < segurados.get(segurados.size() - 1).getPlanos().size(); i++) {
                        System.out.println("  " + segurados.get(segurados.size() - 1).getPlanos().get(i).getNome() + " | numero autorização: " + segurados.get(segurados.size() - 1).getPlanos().get(i).getNumAut());
                    }
                    break;
                case 3:
                    System.out.println("•Criar um procedimento•");
                    System.out.println("Para criar um procedimento selecione um segurado");
                    for (int i = 0; i < segurados.size(); i++) {
                        System.out.println((i + 1) + "-" + segurados.get(i).getNome());
                    }
                    System.out.print("Selecione um segurado: ");
                    opSegurado = Int.nextInt();
                    while (opSegurado < 1 || opSegurado > segurados.size()) {
                        System.out.println("Opção invalida");
                        System.out.print("Selecione um segurado: ");
                        opSegurado = Int.nextInt();
                    }
                    System.out.println(" -Selecione um plano do segurado " + segurados.get(opSegurado - 1).getNome() + "-");
                    for (int i = 0; i < segurados.get(opSegurado - 1).getPlanos().size(); i++) {
                        System.out.println((i + 1) + "-" + segurados.get(opSegurado - 1).getPlanos().get(i).getNome());
                    }
                    System.out.print("Opção:");
                    opPlano = Int.nextInt();
                    while (opPlano < 1 || opPlano > segurados.get(opSegurado - 1).getPlanos().size()) {
                        System.out.println("Opção inválida");
                        System.out.print("Opção:");
                        opPlano = Int.nextInt();
                    }

                    System.out.println("Entre com o nome do procedimento: ");
                    nomeProcedimento = string.nextLine();
                    Procedimento proc = new Procedimento(nomeProcedimento);
                    procedimentos.add(proc);
                    PlanoDeSaúde p4 = new PlanoDeSaúde(segurados.get(segurados.size() - 1).getPlanos().get(opPlano - 1).getNome(), 4);
                    p4.addProcedimento(proc);
                    System.out.println("•Selecione o meio do procedimento•");
                    System.out.println("1 para Ambulatotial");
                    System.out.println("2 para Cirurgico");
                    System.out.print("Opção:");
                    opProcedimento = Int.nextInt();
                    while (opProcedimento < 1 || opProcedimento > 2) {
                        System.out.println("Opçao inválida");
                        System.out.print("Opção:");
                        opProcedimento = Int.nextInt();
                    }
                    switch (opProcedimento) {
                        case 1:
                            System.out.print("Digite a quantidade de técnicos: ");
                            qtdTec = Int.nextInt();
                            System.out.print("Digite o nome da clínica: ");
                            nomeClinica = string.nextLine();
                            System.out.print("Digite o CEP do local: ");
                            cep = Long.nextLong();
                            Ambulatorial amb = new Ambulatorial(qtdTec, nomeClinica);
                            break;
                        case 2:
                            System.out.print("Digite a quantidade de médicos: ");
                            qtdMed = Int.nextInt();
                            System.out.print("Digite o nome do hospital: ");
                            nomeHospital = string.nextLine();
                            System.out.print("Digite o CEP do local: ");
                            cep = Long.nextLong();
                            break;
                    }
                    MenuAutorizar();
                    break;
                case 4:
                    if (procedimentos.size() == 0) {
                        System.out.println("Nenhum procedimento cadastrado!!");
                    } else {
                        System.out.println("•Selecione um procedimento•");
                        for (int i = 0; i < procedimentos.size(); i++) {
                            System.out.println((i+1)+"-"+procedimentos.get(i).getNome());
                        }
                        System.out.print("Opção: ");
                        opProcedimento = Int.nextInt();
                        MenuAutorizar();
                    }
                    break;

                case 5:
                    System.out.println("-------");
                    for (int i = 0; i < operadoras.size(); i++) {
                        System.out.println("Operadora: " + operadoras.get(i).getNome());
                        for (int k = 0; k < operadoras.get(i).getPlanos().size(); k++) {
                            System.out.println("  Plano: " + operadoras.get(i).getPlanos().get(k).getNome() + " | Número de autorização: " + operadoras.get(i).getPlanos().get(k).getNumAut());
                            for (int l = 0; l < operadoras.get(i).getPlanos().get(k).getSegurados().size(); l++) {
                                System.out.println("   Segurado: " + operadoras.get(i).getPlanos().get(k).getSegurados().get(l).getNome() + " | CPF: " + operadoras.get(i).getPlanos().get(k).getSegurados().get(l).getCpf());
                            }
                        }
                        System.out.println("");
                    }
                    System.out.println("-------");
                    break;
            }
            Menu();
        }

    }

    public static void Menu() {
        System.out.println("•MENU INICIAL•");
        System.out.println("Selecione as Opções:");
        System.out.println("0 para Sair");
        System.out.println("1 para Cadastrar um plano no sistema");
        System.out.println("2 para Cadastrar um segurado em um plano");
        System.out.println("3 para Criar um procedimento");
        System.out.println("4 para Mudar autorização do procedimento");
        System.out.println("5 para Visualizar Operadoras&Planos&Segurados");
        System.out.print("Opção:");
        op = Int.nextInt();
        while (op < 0 || op > 5) {
            System.out.println("Opção inválida");
            System.out.print("Opção:");
            op = Int.nextInt();
        }
    }

    public static void MenuOperadora() {
        System.out.println("•Selecione uma operadora•");
        for (int j = 0; j < operadoras.size(); j++) {
            System.out.println((j + 1) + "-" + operadoras.get(j).getNome());
        }
        System.out.print("Opção:");
        opOperadora = Int.nextInt();
        while (opOperadora < 1 || opOperadora > operadoras.size()) {
            System.out.println("Opção inválida");
            System.out.print("Opção:");
            opOperadora = Int.nextInt();
        }
    }

    public static void PlanosOperadora() {//Requer o MenuOperadora para funcionar(variavel opOperadora)
        System.out.println("  -Planos da operadora " + operadoras.get(opOperadora - 1).getNome() + "-");
        for (int i = 0; i < operadoras.get(opOperadora - 1).getPlanos().size(); i++) {
            System.out.println((i + 1) + "-" + operadoras.get(opOperadora - 1).getPlanos().get(i).getNome());
        }
        System.out.print("Opção:");
        opPlano = Int.nextInt();
        while (opPlano < 1 || opPlano > operadoras.get(opOperadora - 1).getPlanos().size()) {
            System.out.println("");
            System.out.println("Opção inválida");
            System.out.print("Opção:");
            opPlano = Int.nextInt();
        }
    }

    public static void MenuAutorizar() {
        System.out.println("•Autorização•");
        System.out.println("1 para Autorizar");
        System.out.println("2 para Negar");
        System.out.print("Opçao: ");
        opAut = Int.nextInt();
        while (opAut < 1 || opAut > 2) {
            System.out.println("Opção inválida");
            System.out.print("Opçao: ");
            opAut = Int.nextInt();
        }

        if (opAut == 1) {
            System.out.println("  Estado: " + Estado.EstadoEnum.AUTORIZADO.estado);
            System.out.println("  Autorizado em: " + autoriza.getData());
        } else {
            System.out.println("  Estado: " + Estado.EstadoEnum.NEGADO.estado);
            System.out.println("  Negado em: " + autoriza.getData());
        }
    }
}
