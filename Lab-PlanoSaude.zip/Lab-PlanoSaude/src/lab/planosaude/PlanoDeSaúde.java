/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.planosaude;

import java.util.ArrayList;

/**
 *
 * @author 31437435 - Matheus Rocha Cruz
 */
public class PlanoDeSaúde {
    
    private ArrayList<Segurado> segurados = new ArrayList();
    private ArrayList<Procedimento> procedimentos = new ArrayList();
    private String nome;
    private long numAut;

    public PlanoDeSaúde(String nome, long numAut) {
        this.nome = nome;
        this.numAut = numAut;
    }

    public ArrayList<Segurado> getSegurados() {
        return segurados;
    }
    
    public void addSegurado(Segurado segurados) {
        this.segurados.add(segurados);
    }
    
    public void addProcedimento(Procedimento procedimentos) {
        this.procedimentos.add(procedimentos);
    }
    
    public void setSegurados(ArrayList<Segurado> segurados) {
        this.segurados = segurados;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public long getNumAut() {
        return numAut;
    }

    public void setNumAut(long numAut) {
        this.numAut = numAut;
    }
}
